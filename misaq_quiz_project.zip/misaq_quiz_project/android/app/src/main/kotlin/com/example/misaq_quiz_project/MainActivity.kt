package com.example.misaq_quiz_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
